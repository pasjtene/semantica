/**
 * Created by NEONZERO on 28/11/2016.
 */

var AppMain = function()
{
    this.params = {
        imagecurrent: $("#head #imagecurrent img"),
        success: $("#seccess")
    };

    this.create = function()
    {

    }
};

